function openCaixa(){

    document.getElementById('caixa').style.display = 'block';

} 

function closeCaixa(){

    document.getElementById('caixa').style.display = 'none';

}

function getItem(){

   return JSON.parse(localStorage.getItem('bdTarefa')) ?? [];

}

function setItem(bdTarefa){

    localStorage.setItem('bdTarefa', JSON.stringify(bdTarefa));

}

function readTarefa(){

    return getItem();
    
}

function criarTarefa(tarefa){

    const bdTarefa = getItem();
    bdTarefa.push(tarefa);
    setItem(bdTarefa);
    renderizarTarefas();
}

function atualizarTarefa(index, tarefa){

    const bdTarefa = readTarefa();
    bdTarefa[index] = tarefa;
    setItem(bdTarefa);
    renderizarTarefas();

}

function deletarTarefa(index){

    const bdTarefa = readTarefa();
    bdTarefa.splice(index, 1);
    setItem(bdTarefa);
    renderizarTarefas();

}

function renderizarTarefas(){

    const tarefas = readTarefa();
    const lista = document.getElementById('listaTarefa');

    lista.innerHTML = tarefas.map((tarefa, index) => `
        <tr>
            <td>${tarefa.titulo}</td>
            <td>${tarefa.descricao}</td>
            <td class="button-container">
                <button onclick="editarTarefa(${index})">Editar</button>
                <button onclick="excluirTarefa(${index})">Excluir</button>
            </td>
        </tr>
    `).join('');
}

function editarTarefa(index){

    const tarefa = readTarefa()[index];
    document.getElementById('titulo').value = tarefa.titulo;
    document.getElementById('descricao').value = tarefa.descricao;
    document.getElementById('botaoSalvar').dataset.index = index;
    openCaixa();

}

function excluirTarefa(index){

    if (confirm('Você tem certeza que deseja excluir esta tarefa?')){
        deletarTarefa(index);
    }
}

function salvarTarefa(){

    const index = document.getElementById('botaoSalvar').dataset.index;
    const tarefa = {
        titulo: document.getElementById('titulo').value,
        descricao: document.getElementById('descricao').value
    };

    if (index === ''){

        criarTarefa(tarefa);
    } else {

        atualizarTarefa(index, tarefa);
    }

    closeCaixa();
    resetCaixa();
}

function resetCaixa(){

    document.getElementById('titulo').value = '';
    document.getElementById('descricao').value = '';
    document.getElementById('botaoSalvar').dataset.index = '';

}

    document.getElementById('cadastrarTarefa').addEventListener('click', () => {
    resetCaixa();
    openCaixa();

});

    document.getElementById('botaoSalvar').addEventListener('click', salvarTarefa);
    document.getElementById('fecharCaixa').addEventListener('click', closeCaixa);

    renderizarTarefas();